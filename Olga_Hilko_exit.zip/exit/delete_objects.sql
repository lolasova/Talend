 DROP SEQUENCE  SEQ_DIM_CUSTOMERS;
 DROP SEQUENCE  SEQ_DIM_PRODUCTS;
 DROP SEQUENCE  SEQ_FCT_PAYMENTS;
 
 drop table PRODUCTS;
 drop table CUSTOMERS;
 drop table PAYMENTS_EXIT;
 drop table PAYMENTS_INVALID;

 drop table FCT_PAYMENTS;
 drop table DIM_PRODUCTS;
 drop table DIM_CUSTOMERS;
 drop table file_loaded_exit;